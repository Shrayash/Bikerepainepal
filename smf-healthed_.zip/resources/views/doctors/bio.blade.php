@extends('layout.apps')

@section('content')
    @if ($errors->count() > 0)
        <div class="alert alert-danger">
            Validation Error:
            <ul class="list-unstyled">
                @foreach ($errors->all() as $error)
                    <li>{{ ucfirst($error) }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session()->has('message'))
        <div class="alert alert-success">{{ session()->get('message') }}</div>
    @elseif(session()->has('error'))
        <div class="alert alert-danger">{{ session()->get('error') }} </div>
    @endif
    <div class="admin-page">
        <div class="admin-page-wrapper">
            @hasanyrole('admin|superadmin')
            @include('admin.sidebar')
            @endhasanyrole

                
            <div class="admin-page-main">
                <div class="admin-page-right create-content-page">
                    @foreach ($doctors as $doctor)
                    <div class="row">
                        <div class="col-md-3">
                            <div id="profile-image"><img src="{{asset('storage/images/').'/'.$doctor->profilepic}}" style="width: 100%"></div>
                        </div>
                        <div class="col-md-7">
                            <h3>Personal Information</h3>
                            <div class="create-content-action ">
                                <div><p> Name : Dr. {{$doctor->user->name}}</p></div>
                                <div><p> Designation : {{$doctor->post}}</p></div>
                                <div><p> Education : {{$doctor->education}}</p></div><br>
                            <h3>Description</h3>
                            <p class="details">
                                {{$doctor->description}}
                            </p>
                            @if( !empty($links))
                                <h3>Connect With Dr. {{$doctor->user->name}}</h3>
                                @foreach ($links as $link)
                                        <a href="{{$link->facebook}}"  target="_blank" rel="noopener noreferrer" ><i class="fa fa-facebook" aria-hidden="true" style="font-size:140%;color:#fff" style="margin-left: 30%"></i></a>&nbsp;&nbsp;&nbsp;
                                        <a href="{{$link->youtube}}"  target="_blank" rel="noopener noreferrer"><i class="fa fa-youtube" aria-hidden="true" style="font-size:140%;color:#fff" style="margin-left: 30%"></i></a>&nbsp;&nbsp;&nbsp;
                                        <a href="{{$link->twitter}}"  target="_blank" rel="noopener noreferrer"><i class="fa fa-twitter" aria-hidden="true" style="font-size:140%;color:#fff" style="margin-left: 30%"></i></a>&nbsp;&nbsp;&nbsp;
                                        <a href="{{$link->linkedin}}"  target="_blank" rel="noopener noreferrer"><i class="fa fa-linkedin" aria-hidden="true" style="font-size:140%;color:#fff" style="margin-left: 30%"></i></a>&nbsp;&nbsp;&nbsp;
                                @endforeach
                            @endif

                        </div>
                    </div></div>
                    @endforeach
                    <div class="row">
                    <div class="create-content-action">
                        <div class="d-block d-sm-none">
                            <br>
                        </div>
                    </div>

                    {{-- <div class="admin-content-box">
                        <div class="content-heading">
                            <h5>Videos</h5>
                        </div>
                        <div class="content-items">
                            @foreach ($videos as $video)
                                <div class="item-box">
                                    <div class="content-title">
                                        <a href="{{ route('video.show', $video['id']) }}">{{ $video['video_lecture'] }}</a>
                                    </div><span></span>
                                    <div class="action-btn">
                                        <span class="edit"><a href="{{ route('video.show', $video['id']) }}">View</a></span>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>
</div>
       
    

@endsection
