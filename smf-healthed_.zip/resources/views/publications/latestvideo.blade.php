                <div class="latest-publication-box">
                    <div class="title-section">
                        <img src="src/assets/images/icons/publication.svg" alt="">
                        <div class="text">
                            <a href="publicationvideo.php">
                                <p class="publication-title">Case Study on Covid-19 cases increment in Nepal</p>
                            </a>
                            <p class="authors">
                                <span class="designation">Author(s):</span>
                                <span class="name">Dr. Munna Bhai</span>
                            </p>
                        </div>
                    </div>
                    <div class="download-section">
                        <a href="publicationvideo.php">
                            <div class="download-button text-center" style="width: 143px;">
                                <span>Watch</span>
                                <img src="src/assets/images/icons/videoplay.svg" alt="">
                            </div>
                        </a>
                    </div>
                </div>                    