<?php

use Illuminate\Database\Seeder;

class categoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            [
                'category'=>'Dental Health',
                'imgname'=>'teeth.svg'
            ],[
                'category'=>'Cardiology',
                'imgname'=>'heart.png'
            ],[
                'category'=>'Gynecology',
                'imgname'=>'vagina.svg'
            ],[
                'category'=>'Ophthalmology',
                'imgname'=>'eye.svg'
            ],[
                'category'=>'Neurology',
                'imgname'=>'brain.svg'
            ],[
                'category'=>'Urology',
                'imgname'=>'kidney.svg'
            ]
        ]);
    }
}
