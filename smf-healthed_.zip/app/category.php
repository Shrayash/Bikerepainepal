<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category extends Model
{
    protected $table='categories';
    public $primaryKey = 'id';
    
    public function videos()
    {
    return $this->hasMany('App\videos','category');
    }
}
