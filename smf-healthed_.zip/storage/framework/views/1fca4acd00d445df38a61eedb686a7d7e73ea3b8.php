<?php $__env->startSection('content'); ?>

    <div class="body-container categories-page">
        <div class="container">
            <h1 class="text-center">
                DISEASES
            </h1>
            <div class="search-box text-center">
               
                  
                   <div class="searchbox">
                    <?php echo csrf_field(); ?>
                        <input type="text" name="video_search" id="video_search"  placeholder="Search for diseases" />
                        <button type="submit" class="search-icon-box" style="border:0%;" onclick="video_search()">
                          <i class="fa fa-search"></i>
                        </button>
                        <ul class="list-group" id="result"></ul>
                       <br />
                    </div>
                   
                       
                
            </div>
            <h3 class="text-center">
                Popular Diseases
            </h3>
            <div class="category-slider-box slider-box">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="owl-carousel carousel-main">
                            
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name=>$group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="slider-content-box">
                                    <a href="<?php echo e(route("video.show", $videos['id'])); ?>">
                                        <div>
                                            <span><?php echo e($name); ?></span>
                                        
                                            <p><a href="<?php echo e(route("video.show", $videos['id'])); ?>"><?php echo e($videos['video_lecture']); ?></a></p> 
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                        </div>
                    </div>
                </div>
            </div>
            
            
            <h3 class="text-center">
                Category
            </h3>
            <div class="category-list-box">
                <div class="row">
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-12 category-box-wrapper">
                        <div class="category-box">
                            <a href="<?php echo e(route('category',$cat->id)); ?>">
                                <h5><?php echo e($cat->category); ?></h5>
                                <div>
                                    <img src="<?php echo e(URL::to('assets/images/icons/').'/'.$cat->imgname); ?>" alt="">
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="text-center">
                <a href="<?php echo e(route('allname')); ?>" class="blue-button show-all-list">See All Diseases</a>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function(){
        
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            console.log(CSRF_TOKEN);
        
         function video_search(search_query = '')
         {
             
          
            $('#result').html('');
                $.ajax({
                url:"<?php echo e(route('video.search')); ?>",
                method:'GET',
                data:{search_query:search_query,_token:CSRF_TOKEN},
                dataType:'json',
                success:function(data)
                {
                    var result = data.data
                    console.log('Result', result[0].id);
                    // console.log('Result1', result.length);
                    if(result.length > 0)
                    {
                        $('#result').html('');
                        for(var count = 0; count < result.length; count++)
                        {
                            var url = "<?php echo e(route('video.show', '')); ?>"+"/"+result[count].id;
                            $('#result').append('<a href="'+url+'"><li class="list-group-item link-class">'+result[count].video_lecture+'</li></a>'); 
                        }
                    }
                    else{
                        $('#result').html('');
                        $('#result').append('<li class="list-group-item link-class">No Data to Display</li>'); 
                    }
                },
                error:function(){
                    console.log('error')}
                
                });
                
         }
                
        $(document).on('keyup', '#video_search', function(){
                    var query = $(this).val();
                    
                    if (query.length > 0 || event.keyCode !== 8 ){
                        video_search(query);
                    }
                    
                });
                });

                $('.carousel-main').owlCarousel({
                        loop: true,
                        autoplay: true,
                        autoplayTimeout: 5000,
                        nav: true,
                        margin: 10,
                        dots: false,
                    navText: ["<i class='fa fa-chevron-left offer-slider-button'></i>","<i class='fa fa-chevron-right offer-slider-button'></i>"],
                    responsiveClass:true,
                        responsive:{
                            0:{
                                items:1,
                                nav:true
                            },
                            767:{
                                items:3,
                                nav:true
                            },
                            991:{
                                items:5,
                                nav:true
                            }
                        }
                    });
        </script>
        
    
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smf-healthed_\resources\views/categories/main.blade.php ENDPATH**/ ?>