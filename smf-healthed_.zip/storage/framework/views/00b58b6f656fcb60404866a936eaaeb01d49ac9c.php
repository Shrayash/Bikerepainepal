<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- META DATA -->
    <meta name="title" content="SMF Health Education Portal">
    <meta name="description" content="SMF Health Education Portal">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <link rel="shortcut icon" href="<?php echo e(asset('assets')); ?>/images/favicon.png">

    <!-- VENDOR CSS FILES -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    
    <!-- FONTS -->
    
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat&family=Roboto:wght@400;500;700&family=Sarabun:wght@600;700&display=swap"
        rel="stylesheet">
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/parsley.min.js"></script>
     
        <script src="<?php echo e(asset('assets')); ?>/js/owl.carousel.min.js"></script>
        <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/owl.carousel.min.css">
   


    <!-- SELECTIVE ASSETS -->

</head>

<header>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|superadmin')): ?>
            <a href="<?php echo e(route("home")); ?>" class="navbar-brand">
               <img src="<?php echo e(asset('assets')); ?>/images/logo.png">
            </a>
            <?php else: ?>
            <a href="<?php echo e(route("index")); ?>" class="navbar-brand">
                <img src="<?php echo e(asset('assets')); ?>/images/logo.png">
            </a>
            <?php endif; ?>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        
                    </li>
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="header-login" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="header-signup" href="<?php echo e(route('register')); ?>"><?php echo e(__('Sign Up')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|superadmin')): ?>
                                     <a class="dropdown-item" href="<?php echo e(route('doctor.bio')); ?>">Profile Settings</a>
                                    <?php endif; ?>
                                    <a class="dropdown-item" href=""
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                    
                </ul>
            </div>
        </div>
    </nav>
</header>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <footer class="footer">
        <div class="container">
            <p class="text-center">
                Copyright Abhiyantrik Technology <?php echo date("Y"); ?>. All Rights Reserved.
            </p>
        </div>
    </footer>
        <script src="<?php echo e(asset('assets')); ?>/js/main.js"></script>
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    
    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\smf-healthed_\resources\views/layout/apps.blade.php ENDPATH**/ ?>