<?php $__env->startSection('content'); ?>

        <div class="page-with-both-sidebar video-content-page">
            <div class="breadcrumb-area">
                <?php ($i=0); ?>
                <div class="container video-breadcrumb-container" style="display: flex;justify-content:space-between;align-items:center;">
                    <div class="breadcrumb-box">
                         <span class="breadcrumb-span"><a href="<?php echo e(route('index')); ?>">Diseases</a></span>
                        <span class="banner-breadcrumb-span"><i class="fa fa-angle-right"></i></span>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="breadcrumb-span"><a href="<?php echo e(route('category',$cat->id)); ?>"><?php echo e($cat->category); ?></a></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <span class="banner-breadcrumb-span"><i class="fa fa-angle-right"></i></span>
                        <span class="breadcrumb-span"><?php echo e($videos['video_lecture']); ?></span>
                    </div>
                    <div class="sidebar-menu-toggler">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>

            <div class="page-wrapper">
                <div class="left-sidebar">
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="videocontent-page-heading-box">
                        <div>
                            <img src="<?php echo e(URL::to('assets/images/icons/').'/'.$cat->imgname); ?>" alt="">
                        </div>
                        <h5><?php echo e($cat->category); ?></h5>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="left-sidebar-nav">
                        <div id="left-nav-accordion" class="category-elements">
                            <?php $__currentLoopData = $similar_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $same): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($i++); ?>
                            <div class="card">
                                <div class="card-header" id="heading <?php echo $i; ?>">
                                <h5 class="mb-0">
                                    <button class="btn btn-link <?php if($i>1) echo "collapsed"; ?>" type="button" data-toggle="collapse" data-target="#collapse<?php echo $i; ?>" aria-expanded="<?php echo ($i==1) ? 'true': 'false'; ?>" aria-controls="collapse<?php echo $i; ?>" >
                                        <?php echo e($same['video_lecture']); ?>

                                    </button>
                                </h5>
                                </div>
        
                                <div id="collapse<?php echo $i; ?>" class="collapse <?php if($i==1) echo 'show'; ?>"  aria-labelledby="heading<?php echo $i; ?>" data-parent="#left-nav-accordion">
                                <div class="card-body">
                                    <ul>
                                        <?php $__currentLoopData = $contents=$same->video_contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('video.show',$same['id'])); ?>"><?php echo e($content->name); ?></a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                    </div>
                </div>
                <div class="right-sidebar">
                    <div class="right-navbar">
                        <div class="right-navbar-heading">
                            <img src="<?php echo e(URL::to('assets')); ?>/images/icons/contents.svg" alt="">
                            <span>CONTENTS</span>
                        </div>
                        <nav class="right-side-navbar">
                            <div>
                                <ul class="">
                                <?php $__currentLoopData = $videocontent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php ($content = get_object_vars($contents)); ?>
                                                        <?php ($name = $content['name']); ?>
                                                        <?php ($description = $content['description']); ?>
                                                        <?php ($link = $content['link']); ?>
                                <li class="right-sidebar-nav-item active"><a href="#section1"><?php echo e($name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </nav>
                    </div>
                </div>

                <div class="main-page-body">
                    <div class="category-page-main-body" >
                        <div id="section1"> 
                            <h1><?php echo e($videos['video_lecture']); ?></h1>
                            <p><?php echo e($videos['video_description']); ?></p>

                            
                        </div>

                        <?php $__currentLoopData = $videocontent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php ($content = get_object_vars($contents)); ?>
                                                        <?php ($name = $content['name']); ?>
                                                        <?php ($description = $content['description']); ?>
                                                        <?php ($link = $content['link']); ?>

                            <div id="section2">
                                <div class="videocontent-page-line"></div>

                                <h4><?php echo e($name); ?></h4>
                                <p><?php echo e($description); ?></p>
                                <div class="video-box">
                                    <iframe width="100%" height="100%" src="<?php echo e($link); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="videocontent-page-line"></div>

                        <div class="video-authors-box">
                            <div class="video-authors">
                                <p class="heading">Video Credits</p>
                                <p class="video-author">
                                    <span class="role">Content: </span>
                                    <span class="name"><?php echo e($videos['contentby']); ?></span>
                                </p>
                                <p class="video-author">
                                    <span class="role">Speaker: </span>
                                    <span class="name"><a href="<?php echo e(route('bio.show',$videos['user_id'])); ?>"><?php echo e($videos['speaker']); ?></a></span>
                                </p>
                            </div>
                        </div>
                        
                        <div class="video-content-controllers">
                            <a href="<?php echo e(URL::to( 'video/show/' . $previous )); ?>" class="left-right-box">
                                <div class="arrow-symbol">
                                    <img src="src/assets/images/icons/left.svg" alt="">
                                </div>
                                <div class="text text-right">
                                    <p class="state">
                                     Previous
                                    </p>
                                    <p class="chapter-name">
                                    <?php $__currentLoopData = $previous_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($video->video_lecture); ?>

                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                </div>
                            </a>
                            <a href="<?php echo e(URL::to( 'video/show/' . $next )); ?>" class="left-right-box">
                                <div class="text">
                                    <p class="state">
                                        Next
                                    </p>
                                    <p class="chapter-name">
                                     <?php $__currentLoopData = $next_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($video->video_lecture); ?>

                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                </div>
                                <div class="arrow-symbol">
                                <img src="src/assets/images/icons/right.svg" alt="">
                                </div>
                            </a>
                        </div>
                    </div>          
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smf-healthed_\resources\views/videocontent/main.blade.php ENDPATH**/ ?>