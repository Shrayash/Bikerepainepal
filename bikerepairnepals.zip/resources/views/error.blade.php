@extends('layout.apps')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
          <img src="{{ URL::to('assets') }}/images/icons/error.svg" width="auto" height="700px" alt=""></div>
          <div class="col-md-2"></div>
        
    </div>
    
            <center><h3>Page Not Found</h3></center><br>
     
</div>

@endsection