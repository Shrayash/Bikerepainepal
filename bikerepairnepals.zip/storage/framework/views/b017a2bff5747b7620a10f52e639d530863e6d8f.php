<?php $__env->startSection('content'); ?>


    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" id="vanish" role="alert">
                <?php echo e(session()->get('message')); ?>

                <button type="button" class="close" data-dismiss="alert" id="vanish" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php elseif(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session()->get('error')); ?> </div>
        <?php endif; ?>
        <div class="main-panel">
            <div class="content-wrapper">
                <br><br>
                <div class="col-12 grid-margin">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h3 class="font-weight-semibold">Customer Detail</h3>
                                <a href="<?php echo e(route('customer.edit',$id)); ?>"><button type="button" 
                                    class="btn btn-danger" > Update Customer Details </button>
                                 </a>
                                <a href="<?php echo e(route('admin.index')); ?>"><button type="button" class="btn btn-primary btn-fw">Back to
                                        Dashboard</button></a>
                            </div>
                  
                            
                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">First name</label>
                                            <h4><b><?php echo e($cust['frst_name']); ?></b></h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Last name</label>
                                            <h4><b><?php echo e($cust['last_name']); ?></b></h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Mobile No.</label>
                                            <h4><b><?php echo e($cust['mobile_no']); ?></b></h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Address</label>
                                            <h4><b><?php echo e($cust['address']); ?></b></h4>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="table table-bordered table-hover" id="dynamicTable">
                                            <tr class="table-active">
                                                <th>Vehicle No.</th>
                                                <!--  <th>Service Date</th> -->
                                                <th>Delivery</th>
                                                <th>Vehicle Remarks</th>
                                                <th>Action</th>
                                            </tr>
                                            <tr>
                                                <th>Ba-023-Pa-2034</th>
                                                
                                                <th>Self</th>
                                                <th>Blue NS 200CC</th>
                                                <th>Example</th>
                                            </tr>
                                           
                                            <?php $__currentLoopData = $customer_vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                            <tr>
                                                <td>
                                                    <p class="font-weight-medium"><?php echo e($vehicle->v_no); ?></p>
                                                </td>
                                                <!-- <td><p class="font-weight-medium">2022-06-13 18:10</p></td> -->
                                                <td>
                                                    <p class="font-weight-medium"><?php echo e($vehicle->delivery); ?></p>
                                                </td>
                                                <td>
                                                    <p class="font-weight-medium"><?php echo e($vehicle->v_remarks); ?></p>
                                                </td>
                                                <td> 
                                                         <?php if(($vehicle->work_status) == 'ongoing'): ?>
                                                         <form class="form-sample" action="<?php echo e(route('service.edit',$vehicle->id)); ?>" >
                                                            <?php echo csrf_field(); ?>
                                                        <button name="work_status"  class="btn btn-box btn-warning" type="submit" value="resolve">Resolve</button>
                                                        </form>
                                                        <?php else: ?>
                                                        <form method="POST" class="form-sample" action="<?php echo e(route('service.start',$vehicle->id)); ?>" >
                                                            <?php echo csrf_field(); ?>
                                                        <button name="work_status"  class="btn btn-box btn-primary" type="submit" value="ongoing">Start Service</button>
                                                        </form>
                                                        <?php endif; ?>
                                                    
                                                           
                                                       
                                                       
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                                


                                <!-- <div class="row">
                    <div class="col-md-12">
                      <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Vehicle No.</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Vehicle Color</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Vehicle Brand</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" />
                        </div>
                      </div>
                    </div>
                  </div> -->



                           
                        </div>
                    </div><br><br>
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h3 class="font-weight-semibold">Customer Service Record</h3>

                            </div>
                            

                            <form class="form-sample">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th>Invoice No</th>
                                                <th>Vehicle No.</th>
                                                <th>Service Date</th>
                                                <th>Delivery</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $resolved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($rec->invoice_no); ?></td>
                                                <td><?php echo e($rec->v_no); ?></td>
                                                <td><?php echo e($rec->updated_at); ?></td> 
                                                <td><?php echo e($rec->delivery); ?></td> 
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                          
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/customer/detail_cust.blade.php ENDPATH**/ ?>