<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class speciality extends Model
{
    protected $table='speciality';
    public $primaryKey = 'id';
}
