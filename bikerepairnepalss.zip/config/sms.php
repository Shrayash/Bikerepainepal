<?php
return [
    'url' => 'http://api.sparrowsms.com/v2/sms/',
    'token' => 'v2_8rsYjHkFEJr4E31nV0f0TNHg8Fl.SIsV',
    'from' => 'BikeRepairs'
];