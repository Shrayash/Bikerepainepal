@extends('layout.apps')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-5" style="margin-top:8%">
          <img src="{{ URL::to('assets') }}/images/icons/error500.svg" width="auto" height="600px" alt=""></div>
          <div class="col-md-4"></div>
        
    </div>
    
            <center><h3>System Error</h3></center><br>
     
</div>

@endsection