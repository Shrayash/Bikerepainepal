                <div class="latest-publication-box">
                    <div class="title-section">
                        <img src="src/assets/images/icons/publication.svg" alt="">
                        <div class="text">
                            <a href="publication.php">
                                <p class="publication-title">Case Study on Covid-19 cases increment in Nepal</p>
                            </a>
                            <p class="authors">
                                <span class="designation">Author(s):</span>
                                <span class="name">Dr. Munna Bhai</span>
                            </p>
                        </div>
                    </div>
                    <div class="download-section">
                        <a href="src/assets/pdf/lorem.pdf" download>
                            <div class="download-button">
                                <span>Download</span>
                                <img src="src/assets/images/icons/download.svg" alt="">
                            </div>
                        </a>
                    </div>
                </div>                    