<?php $__env->startSection('content'); ?>
  

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel">
            <div class="content-wrapper">
                <br><br>
                <div class="col-12 grid-margin">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="font-weight-semibold">Booked Services</h3><br>

                            

                            <form class="form-sample">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th>Name</th>
                                                <th>Vehicle No.</th>
                                                <th>Mobile No.</th>
                                                <th>Booked Date</th>
                                                <th>Time</th>
                                                <th colspan="2">Service Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($service->frst_name); ?><?php echo e($service->last_name); ?></td>
                                                <td><?php echo e($service->v_no); ?></td>
                                                <td><?php echo e($service->mobile_no); ?></td>
                                                <?php ($date_array = explode("T", $service->booked_at)); ?>
                                                <td>
                                                   <?php echo e($date_array[0]); ?></td>
                                                   <td>
                                                    <?php echo e($date_array[1]); ?></td>
                                                <td>
                                                    <form></form>
                                                    <form method="POST" class="form-sample" action="<?php echo e(route('service.start',$service->id)); ?>" >
                                                        <?php echo csrf_field(); ?>
                                                    <button name="work_status"  class="btn btn-box btn-primary" type="submit" value="ongoing">Start</button>
                                                    </form>
                                            </td>
                                            <td>
                                                <form></form>
                                                <form  method="POST" class="form-sample" action="<?php echo e(route('book.cancel',$service->id)); ?>" >
                                                <?php echo csrf_field(); ?>
                                                <button name="preinfo"  class="btn btn-box btn-danger" onclick="return confirm('Are you sure you want to cancel this booking?')" type="submit" value="idle">Cancel</button>
                                            </form>
                                        </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- <nav aria-label="...">
                                    <ul class="pagination">
                                      <li class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                                      </li>
                                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                                      <li class="page-item active">
                                        <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
                                      </li>
                                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                                      <li class="page-item">
                                        <a class="page-link" href="#">Next</a>
                                      </li>
                                    </ul>
                                  </nav> -->

                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/service/booking/booked.blade.php ENDPATH**/ ?>