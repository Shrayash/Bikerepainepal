<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item nav-profile">
        <a href="#" class="nav-link">
          <!-- <div class="profile-image">
            <img class="img-xs rounded-circle" src="assets/images/faces/face8.jpg" alt="profile image">
            <div class="dot-indicator bg-success"></div>
          </div> -->
          <div class="text-wrapper">
            
            <p class="designation">Bike Repairs Nepal</p>
            <!-- <p class="profile-name">Admin Panel</p> -->
          </div>
        </a>
      </li>
      <li class="nav-item nav-category">Admin Panel Menu</li>
      <?php if(auth()->check() && auth()->user()->hasRole('superadmin')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">
          <i class="menu-icon typcn typcn-document-text"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('customer.register_cust')); ?>">
          <i class="menu-icon typcn typcn-document-text"></i>
          <span class="menu-title">Register New</span>
        </a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('customer.check')); ?>">
          <i class="menu-icon typcn typcn-shopping-bag"></i>
          <span class="menu-title">Search Existing</span>
        </a>
      </li>
       <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <i class="menu-icon typcn typcn-coffee"></i>
          <span class="menu-title">Services</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('service.ongoing')); ?>">Ongoing</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('service.resolved')); ?>">Resolved</a>
            </li>
          
          </ul>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
          <i class="menu-icon typcn typcn-document-add"></i>
          <span class="menu-title">Bookings</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="auth">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('customer.newbook')); ?>"> New Customer Booking </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('customer.oldmobile')); ?>"> Old Customer Booking </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('book.request')); ?>"> Booking Requests </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('book.check')); ?>"> Booked Service </a>
            </li>
            
          </ul>
        </div>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">
          <i class="menu-icon typcn typcn-document-text"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="">
          <i class="menu-icon typcn typcn-shopping-bag"></i>
          <span class="menu-title">Book for Service</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="">
          <i class="menu-icon typcn typcn-shopping-bag"></i>
          <span class="menu-title">Servicing History</span>
        </a>
      </li>
      <?php endif; ?>

      <li class="nav-item">
        <a class="nav-link" href="" onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
          <i class="menu-icon typcn typcn-shopping-bag"></i>
          <span class="menu-title">Logout</span>
        </a>
      </li>
     
    
      
      
      
      </ul>
  </nav><?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>