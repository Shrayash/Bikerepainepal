<?php $__env->startSection('content'); ?>
    <?php if($errors->count() > 0): ?>
        <div class="alert alert-danger">
            Validation Error:
            <ul class="list-unstyled">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e(ucfirst($error)); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
  
    <section class="bookbanner" id="top">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-md-offset-1">
                    <div class="banner-caption">
                        <center>
                       
                        <!-- <span>We care for you</span> -->
                        <div class="row">
                            <div class="card">
                                <div class="card-body">
                                    <h2 style="color:#013220;font-weight:bold;">Booking Request Sent!</h2>
                                    <div class="line-dec"></div><br>
                                   Your request has been sent. Please wait for our response as you will recieve a call or text from us soon. If any other queries, feel free to contact us.
                                </div>
                            </div>
                    </div>
                </center>
                    </div>
                   
                </div>
            </div>
        </div>
    </section>

    
    <script>
        $('#vanish').fadeOut(15000);

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/booking/wait_book.blade.php ENDPATH**/ ?>