<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- META DATA -->
    <meta name="title" content="SMF Health Education Portal">
    <meta name="description" content="SMF Health Education Portal">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <link rel="shortcut icon" href="<?php echo e(asset('assets')); ?>/images/favicon.png">

    <!-- VENDOR CSS FILES -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendors/iconfonts/ionicons/dist/css/ionicons.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendors/iconfonts/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/shared/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/demo_1/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/templatemo-style.css">


    <!-- FONTS -->

    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat&family=Roboto:wght@400;500;700&family=Sarabun:wght@600;700&display=swap"
        rel="stylesheet">
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

    <!-- CSS -->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/parsley.min.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/owl.carousel.min.css">
    

    <!-- SELECTIVE ASSETS -->

</head>

<header>
    
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
            <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|superadmin')): ?>
                <a href="<?php echo e(route('home')); ?>" class="navbar-brand brand-logo">
                    <img src="<?php echo e(asset('assets')); ?>/images/logo_main.png">
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('index')); ?>" class="navbar-brand brand-logo">
                    <img src="<?php echo e(asset('assets')); ?>/images/logo_main.png">
                </a>
            <?php endif; ?>

        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center">

            <ul class="navbar-nav ml-auto" style="margin-right: 30px!important;">

                <li class="nav-item">
                    <a class="nav-link" href="#" aria-expanded="false">
                        Home </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link count-indicator" id="messageDropdown" href="#" data-toggle="dropdown"
                        aria-expanded="false">
                        <i class="mdi mdi-help-rhombus"></i>
                        
                    </a>
                    <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0"
                        aria-labelledby="messageDropdown">
                        <a class="dropdown-item py-3">
                            <p class="mb-0 font-weight-medium float-left">Only Employees Allowed ! </p>

                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item preview-item">
                            <!-- <div class="preview-thumbnail">
                                <img src="assets/images/faces/face10.jpg" alt="image" class="img-sm profile-pic">
                                </div> -->
                            <div class="preview-item-content flex-grow py-2">
                                <p class="preview-subject ellipsis font-weight-medium text-dark"> Enter passcode and
                                    manage your workshop mechanism.
                                </p>

                            </div>
                        </a>

                    </div>
                </li>


            </ul>
            <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                data-toggle="offcanvas">
                <span class="mdi mdi-menu"></span>
            </button>
        </div>
    </nav>

</header>

<body>



    

    <div class="container-scroller">
        
        <div class="container-fluid page-body-wrapper full-page-wrapper">
            <div class="content-wrapper d-flex align-items-center auth auth-bg-1 theme-one">
                <div class="row w-100">
                    <div class="col-lg-4 mx-auto">
                        <div class="auto-form-wrapper">

                            
                            
                            <?php if($errors->count() > 0): ?>
                            <div class="alert alert-danger alert-dismissible fade show" id="vanish" role="alert" style="position: relative">
                                <button type="button" class="close" data-dismiss="alert" id="vanish" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <strong>Validation Error:</strong>
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e(ucfirst($error)); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                          <form method="POST" action="<?php echo e(route('login')); ?>" >
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                            <label class="label">Username</label>
                            <div class="input-group">
                                <input id="name" type="text" class=" <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name"
                                autofocus style="width: 100%;">
                                
                            </div>
                            </div>
                            <div class="form-group">
                            <label class="label">Password</label>
                            <div class="input-group">
                                <input id="password" type="password"
                                class="input-type-password <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="password" required autocomplete="current-password" style="width: 90%;">&nbsp;
                                <span toggle="#password" class="fa fa-fw fa-eye  toggle-password" style="margin-top:3%;" ></span>
                                
                               
                                
                            </div>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary submit-btn btn-block" value="Log In">
                            
                        </div>
                        </form>  
                    </div>
                    <br>
                    <center>
                        <p class="text-white">
                            <i class="mdi mdi-check-circle-outline"></i>
                            This page is only for Workshop Members and officials.
                        </p>
                    </center>


                </div>
            </div>
        </div>

    </div>

    </div>


    <footer class="footer">
        <div class="container">

            <p class="text-center">
                Copyright Bike Repairs Nepal <?php echo date('Y'); ?>. All Rights Reserved.
            </p>

        </div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $('#vanish').fadeOut(8000);
    </script>

    <script src="<?php echo e(asset('assets')); ?>/vendors/js/vendor.bundle.addons.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/demo_1/dashboard.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/shared/jquery.cookie.js" type="text/javascript"></script>

    
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/auth/login.blade.php ENDPATH**/ ?>