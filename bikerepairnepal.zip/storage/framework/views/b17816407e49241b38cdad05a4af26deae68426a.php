<?php $__env->startSection('content'); ?>


    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel">
            <div class="content-wrapper">
                <br><br>
                <div class="row page-title-header">
                    <div class="col-12">
                        <div class="page-header">
                            <h4 class="page-title">Set to Resolve and Send SMS</h4>

                        </div>
                    </div>

                </div>
                <div class="col-12 grid-margin">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h4 class="font-weight-semibold">Update Booking Date</h4>
                                
                                
                                <a href="<?php echo e(route('admin.index')); ?>"><button type="button" class="btn btn-primary btn-fw">Back to
                                        Dashboard</button></a>
                                        <form  method="POST" class="form-sample" action="<?php echo e(route('book.cancel',$vehicles->id)); ?>" >
                                            <?php echo csrf_field(); ?>
                                            <button name="preinfo"  class="btn btn-box btn-danger" onclick="return confirm('Are you sure you want to cancel this booking?')" type="submit" value="idle">Booking Cancel</button></form>
                            </div>
                            <br>
                            
        
                           
                            <form class="form-sample" method="POST" action="<?php echo e(route('book.noupdate',$vehicles->id)); ?>"  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" >
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1"><i>*click on calender to update*</i></label>
                                            <input type="datetime-local" name="book_date" id="book_date" class="form-control" value="<?php echo e($vehicles->book_date); ?>"
                                                            required />
                                        
                                        </div>
                                    </div>
                                    
                                </div><br>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">First name</label>
                                            <h4><b><?php echo e($customer->frst_name); ?></b></h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Last name</label>
                                            <h4><b><?php echo e($customer->last_name); ?></b></h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Mobile No.</label>
                                            <h4><b><?php echo e($customer->mobile_no); ?></b></h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Address</label>
                                            <h4><b><?php echo e($customer->address); ?></b></h4>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Vehicle No.</label>
                                            <h4><b><?php echo e($vehicles->book_v_no); ?></b></h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Delivery</label>
                                            <h4><b><?php echo e($vehicles->book_delivery); ?></b></h4>
                                        </div>
                                    </div>
                                </div>
                              
                                
                                <center><button type="submit" class="btn btn-success mr-2">Book Date</button></center>

                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>



<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/service/booking/update_date.blade.php ENDPATH**/ ?>