<?php $__env->startSection('content'); ?>
    <?php if($errors->count() > 0): ?>
        <div class="alert alert-danger">
            Validation Error:
            <ul class="list-unstyled">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e(ucfirst($error)); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
 
    <section class="banner" id="top">
        
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="banner-caption">
                        <div class="line-dec"></div>
                        <h2>Best Service For Your Vehicle</h2>
                        <span>We care for you</span>
                        <div class="row">
                        <div class="col-md-2 blue-button">
                            <a href="<?php echo e(route('customer.newbook')); ?>">Book Now</a>
                        </div>
                        <!-- <div class="col-md-2 red-button">
                            <a href="book_for_customer.html">Old Customer</a>
                        </div> -->
                    </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </section>


        <section class="popular-places" id="popular">
        
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <h3 >About Us</h3><br>
                        <p style="font-size: 20px;">We are the first multibrand two wheeler service center franchisee of Pikpart Smart Garage India  in Nepal. We provide all services related to two wheeler.</p>

                    </div>
                </div> 
            </div> 
        </div>
    </section>

    <section class="featured-places" style="padding-top: 0px!important;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <hr>
                        <span></span>
                        <br><br>
                        <h3 >Our Services</h3><br>
                    </div>
                </div> 
            </div> 
            <div class="row">
                
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="down-content">
                            <h4>Pick n Drop</h4>
                        
                            <p>Get your bike/scooter serviced from your comfort zone.</p><br>
                           
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="down-content">
                            <h4>Express Service</h4>
                        
                            <p>Get your bike/scooter serviced in the quickest time frame.</p><br>
                           
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="down-content">
                            <h4>General Service</h4>
                        
                            <p>General servicing of your bike/scooter in the most efficient manner.</p><br>
                           
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="down-content">
                            <h4>Service Warranty</h4>
                        
                            <p>Each of our service comes with great warranty.</p><br>
                           
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="down-content">
                            <h4>AMC</h4>
                        
                            <p>Save 30% on filling AMC.</p><br>
                           
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="down-content">
                            <h4>Road Assistance</h4>
                        
                            <p>Get your bike/scooter service on any part of the city.</p><br>
                           
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>



    <section class="featured-places" id="blog"  style="padding-top: 0px!important;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <hr>
                        <span></span>
                        <br><br>
                        <h3 >Franchise Glimspe</h3><br>
                    </div>
                </div> 
            </div> 
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="thumb">
                           <iframe width="100%" height="200%" src="https://www.youtube.com/embed/Nwhl1Mq0eGk"> </iframe>
                        </div>
                        <div class="down-content">
                            <h4>Two Wheeler Service Center</h4>
                            <span>Pikpart</span>
                            <p>Smart Garage is India's best Service center chain of Multibrand two wheeler franchisee powered by Pikpart (ROSPL group company). It is a smart  technology enabled futuristic multi revenue generating business model.</p><br>
                            <!-- <div class="row">
                                <div class="col-md-6 first-button">
                                    <div class="text-button">
                                        <a href="#">Add to favorites</a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-button">
                                        <a href="#">Continue Reading</a>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="thumb">
                           <iframe width="100%" height="200%" src="https://www.youtube.com/embed/EVaqU59j8h8"> </iframe>
                        </div>
                        <div class="down-content">
                            <h4>Walkthrough of Smart Garage</h4>
                            <span>Pikpart</span>
                            <p>Smart Garage is India's best Service center chain of Multibrand two wheeler franchisee powered by Pikpart (ROSPL group company). It is a smart  technology enabled futuristic multi revenue generating business model.</p><br>
                            <!-- <div class="row">
                                <div class="col-md-6 first-button">
                                    <div class="text-button">
                                        <a href="#">Add to favorites</a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-button">
                                        <a href="#">Continue Reading</a>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="featured-item">
                        <div class="thumb">
                           <iframe width="100%" src="https://www.youtube.com/embed/19EeB7ZcnUg"> </iframe>
                        </div>
                        <div class="down-content">
                            <h4>Smart Garage Inauguration</h4>
                            <span>Pikpart</span>
                            <p>Smart Garage is India's best Service center chain of Multibrand two wheeler franchisee powered by Pikpart (ROSPL group company). It is a smart  technology enabled futuristic multi revenue generating business model.</p><br>
                            <!-- <div class="row">
                                <div class="col-md-6 first-button">
                                    <div class="text-button">
                                        <a href="#">Add to favorites</a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-button">
                                        <a href="#">Continue Reading</a>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




 


    <section class="contact" id="contact" style="padding-top: 0px!important">
        <div id="map">
        			<!-- How to change your own map point
                           1. Go to Google Maps
                           2. Click on your location point
                           3. Click "Share" and choose "Embed map" tab
                           4. Copy only URL and paste it within the src="" field below
                    -->

           <!--  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1197183.8373802372!2d-1.9415093691103689!3d6.781986417238027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdb96f349e85efd%3A0xb8d1e0b88af1f0f5!2sKumasi+Central+Market!5e0!3m2!1sen!2sth!4v1532967884907" width="100%" height="500px" frameborder="0" style="border:0" allowfullscreen></iframe> -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3532.984016467525!2d85.24908401537927!3d27.68688888280037!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb239844493f69%3A0xce8ea373ca0441ce!2zU2F0dW5nYWwgQ2hvd2sg4KS44KSk4KWB4KSZ4KWN4KSX4KSyIOCkmuCli-CklQ!5e0!3m2!1sen!2snp!4v1651315224683!5m2!1sen!2snp" width="100%" height="500px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        
    </section>
    
    <script>
        $('#vanish').fadeOut(15000);

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/home.blade.php ENDPATH**/ ?>