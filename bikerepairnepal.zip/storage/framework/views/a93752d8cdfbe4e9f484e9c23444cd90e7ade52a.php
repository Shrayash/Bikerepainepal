<?php $__env->startSection('content'); ?>
    

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" id="vanish" role="alert">
                <?php echo e(session()->get('message')); ?>

                <button type="button" class="close" data-dismiss="alert" id="vanish" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php elseif(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session()->get('error')); ?> </div>
        <?php endif; ?>
        <div class="main-panel">
            <div class="content-wrapper">
                <br><br>
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" id="vanish" role="alert">
                    <?php echo e(session()->get('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" id="vanish" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger" role="alert"><?php echo e(session()->get('error')); ?> </div>
            <?php endif; ?>
                <div class="col-12 grid-margin">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h3 class="font-weight-semibold">Register New Customer</h3>
                                <a href="<?php echo e(route('admin.index')); ?>"><button type="button" class="btn btn-primary btn-fw">Back to
                                        Dashboard</button></a>
                            </div>
                            <form method="POST" class="form-sample" action="<?php echo e(route('customer.store')); ?>"
                                id="content_form" data-parsley-validate="">
                                <?php echo csrf_field(); ?>
                                <p class="card-description">Fill the details carefully. </p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">First name</label>
                                            <input type="text" class="form-control" placeholder="First Name"
                                                id="frst_name" data-parsley-required-message="Name Required"
                                                data-parsley-trigger="focusin focusout" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Last name</label>
                                            <input type="text" id="last_name" class="form-control"
                                                placeholder="Last Name" data-parsley-required-message="Name Required"
                                                data-parsley-trigger="focusin focusout" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Mobile No.</label>
                                            <input type="text" id="mobile_no" class="form-control"
                                                placeholder="Mobile Number"
                                                data-parsley-required-message="Mobile Number Required"
                                                data-parsley-trigger="focusin focusout" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Address</label>
                                            <input type="text" id="address" class="form-control" placeholder="Address"
                                                data-parsley-required-message="Address Required"
                                                data-parsley-trigger="focusin focusout" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-responsive">
                                            <table class="table table-bordered" id="dynamicTable">
                                                <thead>
                                                    <tr>
                                                        <th>Vehicle No.</th>
                                                        <th>Distance Covered (KM)</th>
                                                        <th>Delivery</th>
                                                        <th>Vehicle Remarks</th>
                                                        <th>Action</th>
                                                    </tr>
                                                    <tr>
                                                        <th>Ba-023-Pa-2034</th>
                                                        <th>12000</th>
                                                        <th>Self</th>
                                                        <th>Blue NS 200CC</th>
                                                        <th>Example</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="body_table">
                                                    <tr>
                                                        <td><input type="text" name="v_no[]" id="v_no"
                                                                placeholder="Enter Vehicle Number" class="form-control"
                                                                required /></td>
                                                        <td><input type="text" name="distance[]" id="distance"
                                                                placeholder="Enter Distance Covered " class="form-control"
                                                                required /></td>
                                                        <td>
                                                            <select class="form-control" name="delivery[]" id="delivery">
                                                                <option>Select option</option>
                                                                <option value="self">Self</option>
                                                                <option value="pick/drop">Pick/Drop</option>
                                                            </select>
                                                        </td>
                                                        <td><input type="text" name="v_remarks[]" id="v_remarks"
                                                                placeholder="Vehicle color/brand name" class="form-control"
                                                                required /></td>
                                                        <td><button type="button" name="add" id="add"
                                                                class="btn btn-primary">Add More</button></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div><br>
                                <center>

                                    <input type="submit" class="btn btn-box btn-success" name="save" id="save"
                                        value="submit" />
                                </center>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <!-- main-panel ends -->
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/parsley.min.js"></script>
    <script>
        // $(document).ready(function() {
        //     var i = 0;
        //     $("#add").click(function() {
        //         ++i;
        //         $("#dynamicTable").append('<tr><td><input type="text" name="addmore[' + i +
        //             '][name]" placeholder="Enter Vehicle Number" class="form-control" /></td> <td><input type="text" name="addmore[0][name]" placeholder="Enter Distance Covered " class="form-control" /></td><td><select class="form-control" name="product_id"><option>Select option</option><option>Self</option><option>Pick Up/Drop</option></select></td><td><input type="text" name="addmore[' +
        //             i +
        //             '][price]" placeholder="Vehicle color/brand name" class="form-control" /></td><td><button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr>'
        //             );
        //     });

        //     $(document).on('click', '.remove-tr', function() {
        //         $(this).parents('tr').remove();
        //     });

        // });


        $(document).ready(function() {
            $('#add').prop('disabled', true);
           
            $('input[name^=v_remarks]').keyup(function() {
                if ($(this).val() != '') {
                    $('#add').prop('disabled', false);
                }
            });

            $count = 1;
            $iteration = 0;
            $(this).on("click", "#add", function() {
               
                var html = '<tr>';
                $count++;
                $iteration++;
                html +=
                    '<td><input type="text" name="v_no[]" placeholder="Enter Vehicle Number" class="form-control" required /></td>';
                html +=
                    '<td><input type="text" name="distance[]" placeholder="Enter Distance Covered " class="form-control" required /></td>';
                html +=
                    '<td><select class="form-control" name="delivery[]"><option>Select option</option><option value="self">Self</option><option value="pick/drop">Pick/Drop</option></select></td>';
                html +=
                    '<td><input type="text" name="v_remarks[]" placeholder="Vehicle color/brand name" class="form-control" required /></td>';
                html +=
                    '<td><button type="button" name="remove" id="" class="btn btn-danger remove">Remove</button></td></tr>';
                $('.body_table').append(html);
            });



            $(this).on("click", ".remove", function() {
                $(this).closest("tr").remove();
            });



            $('#content_form').on('submit', function(event) {
                var v_no = $('input[name^=v_no]').map(function(idx, elem) {
                    return $(elem).val();
                }).get();
                var distance = $('input[name^=distance]').map(function(idx, elem) {
                    return $(elem).val();
                }).get();
                var delivery = $('select[name^=delivery]').map(function(idx, elem) {
                    return $(elem).val();
                }).get();
                var v_remarks = $('input[name^=v_remarks]').map(function(idx, elem) {
                    return $(elem).val();
                }).get();
                event.preventDefault();
                $.ajax({
                    url: '<?php echo e(route('customer.store')); ?>',
                    method: 'post',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        frst_name: $('#frst_name').val(),
                        last_name: $('#last_name').val(),
                        mobile_no: $('#mobile_no').val(),
                        address: $('#address').val(),
                        v_no: v_no,
                        distance: distance,
                        delivery: delivery,
                        v_remarks: v_remarks
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        $('#save').attr('disabled', 'disabled');
                    },
                    success: function(data) {
                        console.log(data);
                        if (data.error) {
                            var error_html = '';
                            for (var count = 0; count < data.error.length; count++) {
                                error_html += '<p>' + data.error[count] + '</p>';
                            }
                            $('#result').html('<div class="alert alert-danger">' +
                                error_html + '</div>');
                        } else {
                            window.location.href = "/customer/show/"+data.id;
                            // window.location.href = "/admin/index";
                            // window.location.href = "/customer/show/".$id;
                        }
                        $('#save').attr('disabled', false);
                    }
                })
            });



        });
    </script>

<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bikerepairnepal\resources\views/customer/register_cust.blade.php ENDPATH**/ ?>