<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_fb_id_users extends Model
{
    //
}
