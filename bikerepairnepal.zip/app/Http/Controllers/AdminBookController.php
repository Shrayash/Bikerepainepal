<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use DB;
use App\User;
use App\customer;
use App\customer_vehicles;
use App\book_customer;
use App\book_customer_vehicle;
use App\Helpers\Helper;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Cache;

class AdminBookController extends Controller
{

    public function show(Request $request)
    {
        $services = DB::table('book_customer_vehicles')
        ->join('book_customer', 'book_customer_vehicles.book_customer_id', '=', 'book_customer.id')
        ->select('book_customer_vehicles.*', 'book_customer.id','book_customer.frst_name','book_customer.last_name','book_customer.mobile_no')
        ->get();
        
        return view('service.booking.show')->with('services', $services);
    }

    public function show_book(Request $request)
    {

        $services = DB::table('customer_vehicles')
        ->join('customer', 'customer_vehicles.customer_id', '=', 'customer.id')
        ->where('customer_vehicles.preinfo', '=', 'book')
        ->select('customer_vehicles.*', 'customer.id','customer.frst_name','customer.last_name','customer.mobile_no')
        ->get();
        
        return view('service.booking.booked')->with('services', $services);
    }

    public function edit($id)
    {
        $book_vehicle = book_customer_vehicle::findOrFail($id);
        $book_customer = book_customer::where('id','=',$book_vehicle->book_customer_id)->get();
        return view('service.booking.update_date',['customers'=> $book_customer,'vehicles'=> $book_vehicle]);
    }

    public function update_book($id)
    {
  
        $book_vehicle = book_customer_vehicle::findOrFail($id);
        $book_customer = book_customer::where('id','=',$book_vehicle->book_customer_id)->get();
        foreach ($book_customer as $cust) {
        $database_customer = customer::updateOrCreate(
              ['frst_name' => $cust->frst_name,'mobile_no'=>$cust->mobile_no],
              ['frst_name' => $cust->frst_name,
              'last_name' => $cust->last_name,
              'mobile_no'  => $cust->mobile_no,
              'address'  => $cust->address,
              'created_at'  => \Carbon\Carbon::now()->toDateTimeString(),
              'updated_at' => \Carbon\Carbon::now()->toDateTimeString()
              ]
          );
       
      
          $customer_id = DB::table('customer')->where('mobile_no',$cust->mobile_no)->select('id')->get();
        }
     $distance='0';
     $info='book';

          $database_customer_vehicle = customer_vehicles::updateOrCreate(
            ['customer_id'=>$customer_id[0]->id,'v_no'=>$book_vehicle->book_v_no],
            ['customer_id' => $customer_id[0]->id,
            'v_no' => $book_vehicle->book_v_no,
            'distance'  => $distance,
            'delivery'  => $book_vehicle->book_delivery,
            'v_remarks'  => $book_vehicle->book_v_remarks,
            'preinfo'  =>  $info,
            'v_status' => $book_vehicle->book_v_status,
            'work_status'  => $book_vehicle->book_work_status,
            'booked_at' => $book_vehicle->book_date
            ]
        );


    
    
        $book_customer = book_customer::where('id','=',$book_vehicle->book_customer_id)->delete();

        $args = http_build_query(array(
          'token' => config('sms.token'),
          'from'  => config('sms.from'),
          'to'    => $cust->mobile_no,
          'text'  => 'Dear Customer,
Your booking has been confirmed for '.$book_vehicle->book_date.'.
Warm Regards,
Bike Repairs Nepal'));
    
      
    
        # Make the call using API.
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, config('sms.url'));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$args);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    
      // Response
        $response = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
      
        return redirect()->route('customer.show',$customer_id[0]->id);
    
  }



  public function update_to_vehicles(Request $request,$id)
    {
  
    $book_vehicle = book_customer_vehicle::findOrFail($id);
    $book_customer = book_customer::where('id','=',$book_vehicle->book_customer_id)->get();

    $info='book';
    foreach ($book_customer as $cust) {
    $database_customer = customer::updateOrCreate(
          ['frst_name' => $cust->frst_name,'mobile_no'=>$cust->mobile_no],
          ['frst_name' => $cust->frst_name,
          'last_name' => $cust->last_name,
          'mobile_no'  => $cust->mobile_no,
          'address'  => $cust->address,
          'created_at'  => \Carbon\Carbon::now()->toDateTimeString(),
          'updated_at' => \Carbon\Carbon::now()->toDateTimeString()
          ]
      );
   
  
      $customer_id = DB::table('customer')->where('mobile_no',$cust->mobile_no)->select('id')->get();
    }
 $distance='0';
 $info='book';
 $date=$request->get('book_date');
//   dd( $date->toDateTimeString());
      $database_customer_vehicle = customer_vehicles::updateOrCreate(
        ['customer_id'=>$customer_id[0]->id,'v_no'=>$book_vehicle->book_v_no],
        ['customer_id' => $customer_id[0]->id,
        'v_no' => $book_vehicle->book_v_no,
        'distance'  => $distance,
        'delivery'  => $book_vehicle->book_delivery,
        'v_remarks'  => $book_vehicle->book_v_remarks,
        'preinfo'  => $info,
        'v_status' => $book_vehicle->book_v_status,
        'work_status'  => $book_vehicle->book_work_status,
        'booked_at' => $date
    
        ]
    );


    $book_customer = book_customer::where('id','=',$book_vehicle->book_customer_id)->delete();


    $args = http_build_query(array(
      'token' => config('sms.token'),
      'from'  => config('sms.from'),
      'to'    => $cust->mobile_no,
      'text'  => 'Dear Customer,
Your booking has been confirmed for '.$date.'.
Warm Regards,
Bike Repairs Nepal'));

  

    # Make the call using API.
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, config('sms.url'));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,$args);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

  // Response
    $response = curl_exec($ch);
    $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    
  
    return redirect()->route('customer.show',$customer_id[0]->id);
  

  }

  public function check(Request $request)
    {
        return view('service.booking.booked');
      
    }

  public function search(Request $request)
  {

    // $services = DB::table('customer_vehicles')
    // ->join('customer', 'customer_vehicles.customer_id', '=', 'customer.id')
    // ->where('customer.mobile_no', 'like', '%'.$query.'%')
    // ->select('customer_vehicles.*', 'customer.id','customer.frst_name','customer.last_name','customer.mobile_no')
    // ->get();
    // $services = DB::table('customer_vehicles')
    // ->join('customer', 'customer_vehicles.customer_id', '=', 'customer.id')
    // ->where('customer_vehicles.preinfo', '=', 'book')
    // ->select('customer_vehicles.*', 'customer.id','customer.frst_name','customer.last_name','customer.mobile_no')
    // ->get();
    

  if($request->ajax())
  {
   $output = '';
   $query = $request->get('query');
   if($query != '')
   {
    $data = DB::table('customer_vehicles')
    ->join('customer', 'customer_vehicles.customer_id', '=', 'customer.id')
    ->where('customer_vehicles.preinfo', '=', 'book')
    ->select('customer_vehicles.*', 'customer.id','customer.frst_name','customer.last_name','customer.mobile_no')
    ->where('customer.mobile_no', 'like', '%'.$query.'%')
    ->get();
   }
   else
   {
    $data = DB::table('customer_vehicles')
    ->join('customer', 'customer_vehicles.customer_id', '=', 'customer.id')
    ->where('customer_vehicles.preinfo', '=', 'book')
    ->select('customer_vehicles.*', 'customer.id','customer.frst_name','customer.last_name','customer.mobile_no')
    ->get();
   }
   $total_row = $data->count();
   if($total_row > 0)
   {
    foreach($data as $row)
    {
      $date_array = explode("T", $row->booked_at);
      // dd($date_array);
     $output .= '
     <tr>
      <td>'.$row->frst_name.'</td>
      <td>'.$row->v_no.'</td>
      <td>'.$row->mobile_no.'</td>
      <td>'. $date_array[0].'</td>
      <td>'. $date_array[1].'</td>
      <td>'.'<a href="/customer/service/update/'.$row->id.'"><button name="work_status"  class="btn btn-box btn-primary" type="submit" value="ongoing">Start</button></a></td>
      <td>'.'<a href="/customer/service/booking/cancel/'.$row->id.'"><button name="preinfo"  class="btn btn-box btn-danger" onclick="return confirm("Are you sure you want to cancel this booking?")" type="submit" value="idle">Cancel</button></a></td>
      </tr>
     ';
    }
   }
   else
   {
    $output = '
    <tr>
     <td align="center" colspan="5">No Data Found</td>
    </tr>
    ';
   }
   $data = array(
    'table_data'  => $output,
    'total_data'  => $total_row
   );

   echo json_encode($data);
  }
  }

  public function cancel_book(Request $request,$id)
    {
      $idle='idle';
      $customer_update = DB::table('customer_vehicles')->where('id',$id)->update(['preinfo' => $idle]);
      $customer_vehicle = customer_vehicles::findOrFail($id);
      $book_customer = customer::findOrFail($customer_vehicle->customer_id);
      $args = http_build_query(array(
        'token' => config('sms.token'),
        'from'  => config('sms.from'),
        'to'    =>  $book_customer->mobile_no,
        'text'  => 'Dear Customer,
Your booking has been canceled for '.$customer_vehicle->booked_at.'.
Warm Regards,
Bike Repairs Nepal'));
  
    
  
      # Make the call using API.
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, config('sms.url'));
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$args);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  
    // Response
      $response = curl_exec($ch);
      $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);
      return redirect()->route('admin.index');
  

  }
}
