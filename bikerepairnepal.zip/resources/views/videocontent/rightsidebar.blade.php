<div class="right-sidebar">
    <div class="right-navbar">
        <div class="right-navbar-heading">
            <img src="src/assets/images/icons/contents.svg" alt="">
            <span>CONTENTS</span>
        </div>
        <nav class="right-side-navbar">
            <div>
                <ul class="">
                <li class="right-sidebar-nav-item active"><a href="#section1">What is Bleeding Gum?</a></li>
                <li class="right-sidebar-nav-item"><a href="#section2">Symptoms</a></li>
                <li class="right-sidebar-nav-item"><a href="#section3">Causes</a></li>
                <li class="right-sidebar-nav-item"><a href="#section4">Prevention and Treatment</a></li>
            </div>
        </nav>
    </div>
</div>